export interface Color {
  id?: number;
  label: string;
  hex_code: string;
  status: boolean;
}
