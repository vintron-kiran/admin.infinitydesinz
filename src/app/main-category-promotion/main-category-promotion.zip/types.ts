export interface MainCategoryPromotion {
  id: number;
  title: string;
  position: string;
  display_count: number;
  display_rows: number;
  image_url: string;
  status: boolean;
  created_at: string;
}
