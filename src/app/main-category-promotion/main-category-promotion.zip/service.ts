import { MainCategoryPromotion } from './types';

const API_BASE = process.env.NEXT_PUBLIC_API_URL;
const API_URL = `${API_BASE}/main-category-promotions`;

function getToken() {
  return typeof window !== 'undefined' ? localStorage.getItem('authToken') : null;
}

export async function fetchMainCategoryPromotions(): Promise<MainCategoryPromotion[]> {
  const token = getToken();
  const res = await fetch(API_URL, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`Failed to fetch promotions: ${res.status}`);
  return res.json();
}

export async function addMainCategoryPromotion(formData: FormData): Promise<MainCategoryPromotion> {
  const token = getToken();
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: formData,
  });
  if (!res.ok) throw new Error(`Failed to add promotion: ${res.status}`);
  return res.json();
}

export async function updateMainCategoryPromotion(id: number, formData: FormData): Promise<MainCategoryPromotion> {
  const token = getToken();
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: formData,
  });
  if (!res.ok) throw new Error(`Failed to update promotion: ${res.status}`);
  return res.json();
}

export async function deleteMainCategoryPromotion(id: number): Promise<void> {
  const token = getToken();
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  if (!res.ok) throw new Error(`Failed to delete promotion: ${res.status}`);
}
