// products/components/ProductFeatures.tsx
import React, { FormEvent } from 'react';
import styles from '../ProductsMainContent.module.css';

interface ProductFeaturesProps {
  productId: string;
}

export default function ProductFeatures({ productId }: ProductFeaturesProps) {
  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    // TODO: save features for productId
  };

  return (
    <form onSubmit={handleSave}>
      {/* Product Features Section */}
      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>Product Features</h3>
        <div className={styles.fieldGrid}>
          <div className={styles.col3}>
            <label htmlFor="product_code" className={styles.label}>Product Code</label>
            <input id="product_code" name="product_code" type="text" className={styles.input} defaultValue="SOFA001" readOnly />
          </div>
          <div className={styles.col3}>
            <label htmlFor="model" className={styles.label}>Model</label>
            <input id="model" name="model" type="text" className={styles.input} defaultValue="Modern Comfort" readOnly />
          </div>
          <div className={styles.col3}>
            <label htmlFor="type" className={styles.label}>Type</label>
            <input id="type" name="type" type="text" className={styles.input} defaultValue="Sofa" readOnly />
          </div>
          <div className={styles.col3}>
            <label htmlFor="brand" className={styles.label}>Brand</label>
            <input id="brand" name="brand" type="text" className={styles.input} defaultValue="IKEA" />
          </div>

          <div className={styles.col3}>
            <label htmlFor="ideal_for" className={styles.label}>Ideal For</label>
            <input id="ideal_for" name="ideal_for" type="text" className={styles.input} defaultValue="Living Room" />
          </div>
          <div className={styles.col3}>
            <label htmlFor="assembly_required" className={styles.label}>Assembly Required</label>
            <input id="assembly_required" name="assembly_required" type="text" className={styles.input} defaultValue="Yes" />
          </div>
          <div className={styles.col3}>
            <label htmlFor="with_cushions" className={styles.label}>With Cushions</label>
            <input id="with_cushions" name="with_cushions" type="text" className={styles.input} defaultValue="Yes" />
          </div>
          <div className={styles.col3}>
            <label htmlFor="usage" className={styles.label}>Usage</label>
            <input id="usage" name="usage" type="text" className={styles.input} defaultValue="Indoor" />
          </div>

          <div className={styles.col3}>
            <label htmlFor="color" className={styles.label}>Color</label>
            <input id="color" name="color" type="text" className={styles.input} defaultValue="Brown" />
          </div>
          <div className={styles.col9}>
            <label htmlFor="other_features" className={styles.label}>Other Features</label>
            <input id="other_features" name="other_features" type="text" className={styles.input} placeholder="Enter Details" />
          </div>
        </div>
      </div>

      {/* Furniture Details Section */}
      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>Furniture Details</h3>
        <div className={styles.fieldGrid}>
          <div className={styles.col6}>
            <label htmlFor="dimensions" className={styles.label}>Dimensions</label>
            <input id="dimensions" name="dimensions" type="text" className={styles.input} defaultValue="80x35x32 inches" />
          </div>
          <div className={styles.col6}>
            <label htmlFor="weight" className={styles.label}>Weight</label>
            <input id="weight" name="weight" type="text" className={styles.input} defaultValue="45 lbs" />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className={styles.actions}>
        <button type="submit" className={styles.submitBtn}>Update Features</button>
        <button type="reset" className={styles.resetBtn}>Reset</button>
      </div>
    </form>
  );
}
