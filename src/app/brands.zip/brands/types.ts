export interface Brand {
  id?: number;
  name: string;
  logo_url: string;
  status: boolean;
}
