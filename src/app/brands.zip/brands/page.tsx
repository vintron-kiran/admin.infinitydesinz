'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { jwtDecode } from 'jwt-decode';
import BrandsMainContent from './BrandsMainContent';

interface TokenPayload {
  exp: number;
}

export default function BrandsPage() {
  const router = useRouter();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('authToken');

    if (!token) {
      router.replace('/login');
      return;
    }

    try {
      const decoded = jwtDecode<TokenPayload>(token);
      const now = Date.now() / 1000;

      if (decoded.exp < now) {
        localStorage.removeItem('authToken');
        router.replace('/login');
        return;
      }

      setIsReady(true);
    } catch (error) {
      console.error("Token parsing failed", error);
      localStorage.removeItem('authToken');
      router.replace('/login');
    }
  }, [router]);

  if (!isReady) return null;

  return <BrandsMainContent />;
}
